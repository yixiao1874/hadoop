package com.gtja.hadoop;

import org.apache.mahout.cf.taste.hadoop.similarity.item.ItemSimilarityJob;

public class Hello {
    public static void main(String[] args){
        ItemSimilarityJob itemSimilarityJob = new ItemSimilarityJob();
        //itemSimilarityJob.run();
    }
}
